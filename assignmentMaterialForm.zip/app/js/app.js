  var TEMPLATES_URL = 'app/templates/';
  
  // Prepare the 'users' module for subsequent registration of controllers and delegates
  var app = angular.module('assignmentOne', [ 'ui.router', 'ngMaterial' ]);